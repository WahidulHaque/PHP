function confirmation() 
{
	var con = confirm("Are you sure all the information you provided are correct?\nPress 'OK' to proceed.\nPress 'CANCEL' to re-check.");
	
	return con;
	
}