<?php
    header ('Location:Pages/index.php');
?>